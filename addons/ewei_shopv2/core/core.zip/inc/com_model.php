<?php

class ComModel
{}

if (!defined('IN_IA')) {
	exit('Access Denied');
}

?>
