<?php
//QQ63779278
if (!defined('IN_IA')) {
	exit('Access Denied');
}

class H5app_EweiShopV2ComModel extends ComModel
{}

?>
